Báo cáo đồ án
	 
- Hoàn thành: 100% các yêu cầu
- Do thời gian gấp rút nên chưa thể kiểm soát hết các lỗi input
- Code rối, không gọn, đọc khó hiểu

Cách chạy và cài đặt

* Yêu cầu 

- python 3.8.3 (32bit)
- Các thư viện, packet python:

	base64, hashlib, Crypto, Crypto.Cipher, random
	import handle_raw_data as hrd

- Ý tưởng đồ án
+ Cấu trúc volume:

	path,data(bytes),password
	
	ví dụ:

	test/,,
	test/a.txt,dữ liệu 123,password
	test/b.txt,dữ liệu 123,
	test/sub2/,,
	test/sub2/sub_3/,,
	test/sub2/sub_3/c.txt,dữ liệu 123,
	test/sub_dir/,,
	test/sub_dir/b.txt,dữ liệu 123,

+ Các bước Lấy tất cả các path của thư mục cần tạo vol, tạo cấu trúc vol, encrypt file > file.vol

+ Chép file từ vol ra ngoài: giải mã copy data file ra ngoài, tạo file mới ở ngoài

+ chép file từ ngoài vào vol: tạo theo cấu trúc vol, giải mã vol thêm dữ liệu mới vào, cập nhật lại vol và mã hoá

+ xoá file: giải mã vol, tìm vị trí xoá khỏi vol, cập nhật vol, mã hoá trở lại.


-------------------------------------------------------------

Cách chạy:



Runcode 

        1. Make volume.
        2. Show list files.
        3. Set a password to a file.
        4. Export a file.
        5. Import a file.
        6. Delete a file.
        0: Exit

Your select:

nhấn số để lựa chọn

ví dụ:

1. make volume

Your select: 1
folder name: test
check test.vol in your current directory
press any key to continue....


--> file test.vol sẽ được tạo


2. show list files --> show ra cây thư mục:

Your select: 2
input vol-name: test.vol
test
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

press any key to continue....


3. set a password to a file:

Your select: 3
input vol-name: test.vol
test
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

input path: test/sub_dir/b.txt
input password:1234
press any key to continue....



4. Export a file


Your select: 4
input vol-name: test.vol
test
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

input path: test/sub_dir/b.txt
password(default: blank): 1234
check  b.txt  in your current working directory
press any key to continue....


nội dung b.txt [dữ liệu tiếng việt]

--> không có password thì bỏ trống


5. import a file


Your select: 5
import file's path: import test file.txt
import to vol-name: test.vol
test
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

import to folder path: test/
import successful
test
        import test file.txt
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

press any key to continue....




6. Delete file



Your select: 6 
import to vol-name: test.vol
test
        import test file.txt
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

input target path: test/import test file.txt
delete successful
test
        a.txt
        b.txt
        c.bmp
        sub2
                aa.txt
                sub_3
                        c..txt
        sub_dir
                b.txt
                dir_new
                dir_new2
                        a.txt

press any key to continue....


0. Exit

Your select: 0
Exit...


