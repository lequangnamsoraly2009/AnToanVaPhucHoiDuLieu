

def Directory_tree(raw_data):
    '''
    raw_data format: 'path,pwd,data','path2,pwd2,data2,.....']
    ['test/,,', 'test/a.txt,,dữ liệu 123', 'test/b.txt,,dữ liệu 123', 'test/sub2/,,', 'test/sub2/sub_3/,, ', 'test/sub2/sub_3/c.txt,,dữ liệu 123', 'test/sub_dir/, ,', 'test/sub_dir/b.txt,,dữ liệu 123'] 
    '''
    d_tree = ''
    for i in raw_data:
        b = i.split(',')[0]
        if b[-1] == '/':
            c = b.split('/')
            d_tree += ('\t'*(len(c) - 2) + c[-2] + '\n')
        else:
            c = b.split('/')
            d_tree += ('\t'*(len(c) - 1) + c[-1] + '\n')
    return d_tree

# a = Directory_tree(raw_data = l_rawdata)
# print(a)

def set_pwd(raw_data, pwd, path='test/'):
    paths = []
    matched_path = []
    for i in raw_data:
        paths.append(i.split(',')[0])
    for p in paths:
        if path in p:
            matched_path.append(p)
    if matched_path == []:
        print('no match path found')
        return raw_data
    v = []
    for i in raw_data:
        l = i.split(',')
        for j in matched_path:
            if l[0] == j:
                l[-1] = pwd
        v.append(l)
    '''
    v format
    [['test/', '', '1234'], ['test/a.txt', 'dữ liệu 123', '1234'], ['test/b.txt', 'dữ liệu 123', '1234'], ['test/sub2/', '', '1234'], ['test/sub2/sub_3/', '', '1234'], ['test/sub2/sub_3/c.txt', 'dữ liệu 123', '1234'], 
    ['test/sub_dir/', '', '1234'], ['test/sub_dir/b.txt', 'dữ liệu 123', '1234']]
    '''
    raw_data = []
    for i in v:
        raw_data.append(','.join(i))
    return raw_data       
# new_data = set_pwd(raw_data = l_rawdata, pwd = '1234',path='test/')


def export_file(raw_data,pwd='',path='test/'):
    if path[-1] == '/':
        print('input a path\'s file')
        return -1   
    paths = []
    matched_path = []
    for i in raw_data:
        paths.append(i.split(',')[0])
    for p in paths:
        if path == p:
            matched_path.append(p)
    if matched_path == []:
        print('no match path found')
        return -1
    for i in raw_data:
        if matched_path[0] == i.split(',')[0]:  

            if pwd == i.split(',')[-1]:
                return i
            else:
                print('wrong password')
                return -1

# data_exported = export_file(raw_data = new_data,pwd = '1234', path='test/b.txt')
# print(data_exported)

def import_data(import_raw_data, raw_data):
    b = import_raw_data.split(',')[0]
    c = ''
    for i in range(len(b) - 1,-1,-1):
        if b[i] == '/':
            c = b[:i+1]
            break
    for i in range(len(raw_data)):
        a = raw_data[i].split(',')[0]
        if a == c:
            raw_data.insert(i+1,import_raw_data)
            return raw_data
    return -1


'''
a = import_data(import_raw_data='test/sub_dir/c.txt,chiều hôm ấy,1234',raw_data=new_data)

if a == -1:
    print('no path found')
else:
    new_data = a
    print(a)

b = Directory_tree(a)
print(b)
'''


def del_data(del_raw_data, raw_data):
    a = del_raw_data
    for i in range(len(raw_data)):
        b = raw_data[i].split(',')[0]
        if a == b:
            raw_data.remove(raw_data[i])
            return raw_data

    return -1

# a = del_data(del_raw_data='test/sub2/sub_3/c.txt', raw_data=new_data)

# if a == -1:
#     print('no path found')
# else:
#     new_data = a
#     print(a)
# b = Directory_tree(a)
# print(b)