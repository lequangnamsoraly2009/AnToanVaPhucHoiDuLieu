from pathlib import Path
import os
import AES
import sys
defaultfile=b"0000000000000021root%folder%0%%'root'"
#Class chua thong tin ve tung file, thu muc
class Tree:
    def __init__(self,FileInfo: dict):#khoi tao mot Tree voi thong tin dua vao gom ten file, loai file va dung luong file
        self.FileInfo=FileInfo
        if self.FileInfo['File_type']=='folder':
            self.FileInfo['size']=0
            self.children=[]
    def _add_Leaf(self,Leaf):#them mot fil hoac thu muc vao mot thu muc chi dinh
        if self.FileInfo['File_type']=='folder':
            self.children.append(Leaf)
            Leaf.FatherFolder=self.FileInfo['Name']
            self.FileInfo['size']=self.FileInfo['size']+Leaf.FileInfo['size']
            return True
        else:
            raise ValueError('AddFileOrFolderToFileERR')
    def __str__(self, level=0):#in ra man hinh cay cau truc tu root
        ret = "\t"*level+repr(self.FileInfo['Name'])+"\n"
        if self.FileInfo['File_type']=='folder':
            for child in self.children:
                ret += child.__str__(level+1)
        return ret
    def _update_size(self,level=0):#cap nhat kich thuoc cac folder dua vao cac thu muc con va file con
        size=0
        if self.FileInfo['File_type']=='folder':
            for child in self.children:
                size=size+child._update_size(level+1)
            self.FileInfo['size']=size
            return self.FileInfo['size']
        else:
            return self.FileInfo['size']
        
    def __repr__(self):
        return self.Name()
    def Name(self):
        return self.FileInfo['Name']
    def FileType(self):
        return self.FileInfo['File_type']
    def FileSize(self):
        return self.FileInfo['size']


#Class My File System
class MFS:
    Path_To_FS=''
    leaf=[]
    root=''
    data=''
    lendata=0
    lenTree=0
    def __init__(self,path_to_FS):#ham khoi tao class tu file co san, neu khong co thì tao file rong co dang nhu newMFS.FS
        path=Path(path_to_FS)
        if path.exists():
            self.ReadTree(path_to_FS)
            self.Path_To_FS=path_to_FS
        else:
            print('File Or Path Not Found, Do you want to create new ? (Y//n)')
            if (input()=='Y'):
                pathdir=os.path.dirname(os.path.abspath(path_to_FS))
                fileFSname=os.path.basename(path_to_FS)
                path_to_FS=os.path.join(pathdir,fileFSname)
                if (os.path.exists(pathdir)):
                    fs=open(path_to_FS,'wb')
                    fs.write(defaultfile)
                    fs.close()
                    self.ReadTree(path_to_FS)
                    self.Path_To_FS=path_to_FS
                else:
                    try:
                        os.makedirs(pathdir)
                        fs=open(path_to_FS,'wb')
                        fs.write(defaultfile)
                        fs.close()
                        self.ReadTree(path_to_FS)
                        self.Path_To_FS=path_to_FS
                    except:
                        raise ValueError("Can't make dir")
            else:
                sys.exit()




    
    def ReadTree(self,path_to_FS):#ham doc cau truc hinh cay tu file
        FS=open(path_to_FS,'rb')
        lenTree=FS.read(16)
        lenTree=int(lenTree)
        self.lenTree=lenTree
        self.BytesToTree(FS.read(lenTree))
        self.data=FS.read()
        self.lendata=len(self.data)

    def TreeToRawBytes(self): #ham chuyen doi cau truc cay thanh chuoi cac bytes de luu lai
        stringform=''
        for i in range(len(self.leaf)):
            if i==len(self.leaf)-1:
                stringform=stringform+self.leaf[i].Name()+'%'+self.leaf[i].FileType()+'%'+str(self.leaf[i].FileSize())+'%%'
            else:
                stringform=stringform+self.leaf[i].Name()+'%'+self.leaf[i].FileType()+'%'+str(self.leaf[i].FileSize())+'%'
        stringform=stringform+str(self.root)
        stringform=stringform[:-1]
        stringform=repr(stringform)
        stringform=stringform[1:-1]
        return stringform

    def BytesToTree(self,bytes_str):#ham chuyen doi mot chuoi bytes thanh cau truc cay
        bytes_str=bytes_str.decode('utf-8')
        TreeString=bytes_str.split('%%')#chuoi dua vao duoc tach lam 2 phan: +phan dic la phan chua danh sach cac thu muc, file
        dic=TreeString[0].split('%')
        if len(dic)%3==0:
            len_leaf=int(len(dic)/3)
            for i in range(int(len_leaf)):
                self.leaf.append(Tree({'Name':dic[i*3],'File_type':dic[i*3+1],'size':int(dic[i*3+2])}))
        else:
            raise ValueError('InputLeafnot%3==0')
        TreePOS=TreeString[1].replace('\'','')# +phan TreePOS la thu tu thu muc cha thu muc con cua cac thu muc, file
        TreePOS=TreePOS.split('\\n')
        POS=[]
        for i in range(len(TreePOS)):#vong lap tao mot tuple chua do sau(deep/level) cua thu muc, va ten thu muc, file
            temp=(TreePOS[i].count('\\t'),TreePOS[i].replace('\\t',''))
            POS.append(temp)
        for i in range(len(POS)):#bat dau gan thu muc con, thuat toan o day la: thu muc/file o do sau 'n' se la con cua thu muc co do sau 'n-1' dau tien ben trai no.
            key=True
            if POS[i][0]==0:
                continue
            else:#vi chi co ten cua file/folder nen can su dung nhieu vong lap de tim duoc object Tree cua file/folder do
                for j in range(i,-1,-1):
                    if POS[j][0]==POS[i][0]-1:
                        for u in range(len_leaf):
                            if self.leaf[u].Name()==POS[i][1]:
                                for t in range(len_leaf):
                                    if self.leaf[t].Name()==POS[j][1]:
                                        if key:
                                            self.leaf[t]._add_Leaf(self.leaf[u])
                                            key=False
                                        else:
                                            continue
                                        
        for i in range(len_leaf):#gan object root cho MFS 
            if self.leaf[i].Name()=='root':
                self.root=self.leaf[i]
        self.root._update_size()

    def _add_File(self,path_to_fileIn,FatherFolder):#ham them file vao MFS
        path=Path(path_to_fileIn)
        if path.exists():
            filein=open(path_to_fileIn,'rb')
            filename=os.path.basename(path_to_fileIn)
            data=filein.read()
            lenfilein=len(data)
            newfile=Tree({'Name':filename,'File_type':'file','size':lenfilein})
            self.leaf.append(newfile)
            self.data+=data
            self.lendata=len(self.data)
            for i in range(len(self.leaf)):
                if self.leaf[i].Name()==FatherFolder and self.leaf[i].FileType()=='folder':
                    self.leaf[i]._add_Leaf(newfile)
                    break
        self.root._update_size()#them file thi can update size toan bo cay
        
    def _save_(self,path_and_nameMFS):#luu file ra ngoai
        TreeString=self.TreeToRawBytes()
        lenTree=len(TreeString)
        lenTree=str(lenTree)
        while(len(lenTree)!=16):
            lenTree='0'+lenTree
        saveBin=lenTree.encode('utf-8')+TreeString.encode('utf-8')+self.data
        saveFile=open(path_and_nameMFS,'wb')
        saveFile.write(saveBin)
        print('Save Success')

    def _add_new_folder(self,foldername,Leaf_father): #ham them thu muc
        newfolder=Tree({'Name':foldername,'File_type':'folder','size':0})
        self.leaf.append(newfolder)
        Leaf_father._add_Leaf(newfolder)

    def __str__(self):
        for i in range(len(self.leaf)):
            if self.leaf[i].Name()=='root':
                self.root=self.leaf[i]
        return self.root.__str__()

    def _ExportFile_(self,location,filename):#ham export file ra ngoai
        begin=0
        key=True
        for i in range(len(self.leaf)):#vong lap tin vi tri bat dau cua file trong data va lay size cua no
            if self.leaf[i].FileInfo['Name']==filename:
                FileEX=self.leaf[i]
                key=False
                break
            else:
                if key and self.leaf[i].FileInfo['File_type']!='folder':#khong the Export folder
                    begin=begin+self.leaf[i].FileInfo['size']
        if begin<self.lendata and begin+FileEX.FileInfo['size']<=self.lendata:#kiem tra do dai doan data co du khong
            data=self.data[begin:begin+FileEX.FileInfo['size']]
            fileout=open(location+filename,'wb')
            fileout.write(data)
            fileout.close()
        else:
            raise ValueError('OutOfRangeIndata')
    
    def EncryptInFS(self,filename): #ma hoa bang AES va CFB, lay code tu cac do an truoc do chinh em lam
        begin=0#phan duoi giong nhu phan Export dung de lay ra data de ma hoa
        key=True
        for i in range(len(self.leaf)):
            if self.leaf[i].FileInfo['Name']==filename:
                FileEX=i
                key=False
                break
            else:
                if key and self.leaf[i].FileInfo['File_type']!='folder':
                    begin=begin+self.leaf[i].FileInfo['size']
        if begin<self.lendata and begin+self.leaf[FileEX].FileInfo['size']<=self.lendata:
            data=self.data[begin:begin+self.leaf[FileEX].FileInfo['size']]
            print('Nhập Password:')
            password=input()
            EncryptData=AES.EncryptionFS(data,password)
            En=bytes(EncryptData)
            #chen data da duoc ma hoa vao data, cap nhat lai size cho toan bo
            self.data=self.data[:begin]+En+self.data[begin+self.leaf[FileEX].FileInfo['size']:]
            self.leaf[FileEX].FileInfo['size']=len(En)
            self.root._update_size()
            self.lendata=len(self.data)
            

    def DecryptInFS(self,filename):#giai ma: tuong tu phia tren
        begin=0
        key=True
        for i in range(len(self.leaf)):
            if self.leaf[i].FileInfo['Name']==filename:
                FileEX=i
                key=False
                break
            else:
                if key and self.leaf[i].FileInfo['File_type']!='folder':
                    begin=begin+self.leaf[i].FileInfo['size']
        if begin<self.lendata and begin+self.leaf[FileEX].FileInfo['size']<=self.lendata:
            data=self.data[begin:begin+self.leaf[FileEX].FileInfo['size']]
            print('Nhập Password:')
            password=input()
            DecryptData=AES.DecryptionFS(data,password)
            De=bytes(DecryptData)
            self.data=self.data[:begin]+De+self.data[begin+self.leaf[FileEX].FileInfo['size']:]
            self.leaf[FileEX].FileInfo['size']=len(De)
            self.root._update_size()
            self.lendata=len(self.data)
        
    def DelFile(self,filename,FatherFolder):#xoa file: xoa data va xoa object tree do khoi self.leaf va trong thu muc cha cua no
        begin=0
        key=True
        for Leaf in self.leaf:
            if Leaf.FileInfo['Name']==FatherFolder:
                for i in range(len(Leaf.children)):
                    if Leaf.children[i].FileInfo['Name']==filename:
                        FileDel=Leaf.children[i]
                        Leaf.children.pop(i)
                        break
                break
        
        for i in range(len(self.leaf)):
            if self.leaf[i].FileInfo['Name']==filename and self.leaf[i].FileInfo['size']==FileDel.FileInfo['size'] :
                FileEX=i
                key=False
                break
            else:
                if key and self.leaf[i].FileInfo['File_type']!='folder':
                    begin=begin+self.leaf[i].FileInfo['size']
        if begin<self.lendata and begin+self.leaf[FileEX].FileInfo['size']<=self.lendata:
            self.data=self.data[:begin]+self.data[begin+self.leaf[FileEX].FileInfo['size']:]
            self.lendata=len(self.data)
        self.leaf.pop(FileEX)
        self.root._update_size()
        print('Del '+filename+' Success')

    def DelFolder(self,foldername,FatherFolder):#xoa thu muc: xoa tat ca cac file trong thu muc sau do ms bat dau xoa no nhu file
        for i in range(len(self.leaf)):
            if self.leaf[i].FileInfo['Name']==foldername:
                if len(self.leaf[i].children)>0:
                    for chil in self.leaf[i].children:
                        self.DelFile(chil.FileInfo['Name'],foldername)
                self.leaf.pop(i)
                break
        for Leaf in self.leaf:
            if Leaf.FileInfo['Name']==FatherFolder:
                for i in range(len(Leaf.children)):
                    if Leaf.children[i].FileInfo['Name']==foldername:
                        Leaf.children.pop(i)
                        break
                break


        
        

#----Lenh Doc File MFS
#t=MFS('newMFS.FS')#file nay la file rong, co moi root
# t=MFS('FileMFS.FS')#file nay chua file hinh anh

#---Lenh them file:
# t._add_File('testaddfile.txt','temp')
# t._add_File('images.jfif','text')

# print(t) #la lenh in ra cau truc hinh cay cua MFS

# t._save_('FileMFS.FS') # lenh save 

# t._ExportFile_('','images.jfif')#lenh export
# t.EncryptInFS('images.jfif')#lenh ma hoa
# t.DecryptInFS('images.jfif')#lenh giai ma

# t.DelFile('testaddfile.txt','temp')#lenh xoa file
# t.DelFolder('temp','root')#lenh xoa folder

#VD:
t=MFS('test/FileMFS.FS')
print(t)
t._add_File('FileinfolderVar.txt','var')
print(t)


